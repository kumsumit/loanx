import 'package:flutter/material.dart';
import 'package:mortgage/db/mortgage.dart';

class MortgageDetails extends StatelessWidget {
  const MortgageDetails({super.key, required this.mortgage});
  final Mortgage mortgage;

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
