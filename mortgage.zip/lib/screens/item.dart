import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/provider/provider.dart';

class ItemView extends HookWidget {
  const ItemView({super.key});
  @override
  Widget build(BuildContext context) {
    final itemInputController = useTextEditingController();

    return Scaffold(
      body: Consumer(builder: (context, ref, child) {
        final items = ref.watch(itemListProvider);
        return ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, index) {
            final item = items[index];
            return ListTile(
              title: Text(item.name),
              onTap: () => ref.read(itemListProvider.notifier).delete(item.id!),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton(
          onPressed: () async {
            final dialog = await showDialog(
              context: context,
              builder: (BuildContext context) => AlertDialog(
                title: const Text('Add item'),
                content: TextField(
                  autofocus: true,
                  decoration:
                      const InputDecoration(hintText: 'Enter the item name'),
                  controller: itemInputController,
                ),
                actions: [
                  Consumer(builder: (context, ref, child) {
                    return TextButton(
                      child: const Text('Submit'),
                      onPressed: () {
                        ref
                            .read(itemListProvider.notifier)
                            .add(itemInputController.text);
                        Navigator.of(context).pop();
                      },
                    );
                  }),
                ],
              ),
            );
            // Clear text after dialog is dismissed.
            itemInputController.clear();
            return dialog;
          },
          child: Icon(Icons.add)),
    );
  }
}
