import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/provider/provider.dart';

class FamilyRelationView extends HookWidget {
  const FamilyRelationView({super.key});

  @override
  Widget build(BuildContext context) {
    final familyInputController = useTextEditingController();
    return Scaffold(
      body: Consumer(builder: (context, ref, child) {
        final familyRelations = ref.watch(familyRelationListProvider);
        return ListView.builder(
          itemCount: familyRelations.length,
          itemBuilder: (context, index) => ListTile(
            title: Text(familyRelations[index].name),
          ),
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final dialog = await showDialog(
            context: context,
            builder: (BuildContext context) => AlertDialog(
              title: const Text('Add Family Relation'),
              content: TextField(
                autofocus: true,
                decoration: const InputDecoration(
                    hintText: 'Enter the Family Relation name'),
                controller: familyInputController,
              ),
              actions: [
                Consumer(builder: (context, ref, child) {
                  return TextButton(
                    child: const Text('Submit'),
                    onPressed: () {
                      ref
                          .read(familyRelationListProvider.notifier)
                          .add(familyInputController.text);
                      Navigator.of(context).pop();
                    },
                  );
                }),
              ],
            ),
          );
          // Clear text after dialog is dismissed.
          familyInputController.clear();
          return dialog;
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
