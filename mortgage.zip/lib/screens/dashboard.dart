import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:mortgage/screens/home.dart';
import 'package:mortgage/screens/manage.dart';

import 'drawer.dart';

class DashBoard extends HookWidget {
  const DashBoard({super.key});

  final List<Widget> _pages = const [
    Home(),
    Manage(),
  ];

  @override
  Widget build(BuildContext context) {
    final currentIndex = useState<int>(0);
    final title = useState<String>("Mortgage");
    // uploadGoogleDrive(context);
    return Scaffold(
      appBar: AppBar(title: Text(title.value)),
      drawer: MyDrawer(),
      body: _pages[currentIndex.value],
      bottomNavigationBar: BottomNavigationBar(
        //  shape: CircularNotchedRectangle(),
        currentIndex: currentIndex.value,
        onTap: (index) {
          currentIndex.value = index;
          title.value = index == 0 ? "Mortgage" : "Manage";
        },
        // selectedItemColor: isDark(context) ? color : Colors.amber,
        unselectedItemColor: const Color.fromARGB(255, 243, 219, 142),
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Manage',
          ),
        ],
      ),
    );
  }
}
