import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/db/family_relation.dart';
import 'package:mortgage/db/item.dart';
import 'package:mortgage/db/mortgage.dart';
import 'package:mortgage/db/mortgage_material.dart';
import 'package:mortgage/provider/provider.dart';
import 'package:mortgage/widget/notched_dropdown.dart';
import 'package:mortgage/widget/styled_dropdown.dart';
import 'package:mortgage/widget/styled_text_widget.dart';

/// Interface to add a new or update an existing mortgage.
///
/// Supports adding or changing the text and setting the associated tag of
/// a task.
class MortgageInput extends HookConsumerWidget {
  final Mortgage? mortgage;

  /// If [mortgageId] is not null, the id of the mortgage to edit.
  /// Otherwise, will create a new task.
  const MortgageInput({super.key, this.mortgage});

  double _parseDouble(String input) {
    try {
      return double.parse(input);
    } catch (e) {
      try {
        return int.parse(input).toDouble();
      } catch (ie) {
        return 0.0;
      }
      // Default value if parsing fails
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appBarTitle = mortgage == null ? "Add Mortgage" : "Edit Mortgage";
    final isDialogOpen = useState<bool>(false);
    final items = ref.watch(itemListProvider);
    final familyRelations = ref.watch(familyRelationListProvider);
    final mortgageMaterials = ref.watch(mortgageMaterialListProvider);
    final currentItem =
        useState<Item>(mortgage == null ? items.first : items.firstWhere((element) => element.id == mortgage!.itemId));
    final currentFamilyRelation = useState<FamilyRelation>(mortgage == null
        ? familyRelations.first
        : familyRelations.firstWhere((element) => element.id == mortgage!.familyRelationId));
    final currentMortgageMaterial = useState<MortgageMaterial>(mortgage == null
        ? mortgageMaterials.first
        : mortgageMaterials.firstWhere((element) => element.id == mortgage!.mortgageMaterialId));
    final depositorController = useTextEditingController();
    final addressController = useTextEditingController();
    final relationTypeController = useTextEditingController();
    final loanAmountController = useTextEditingController();
    final interestRateController = useTextEditingController();
    final weightController = useTextEditingController();
    final additionalDetailsController = useTextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Text(appBarTitle),
        foregroundColor: const Color.fromARGB(255, 158, 119, 3),
      ),
      body: Padding(
          padding: EdgeInsets.only(
              bottom: isDialogOpen.value
                  ? 20
                  : MediaQuery.of(context).viewInsets.bottom,
              left: 20,
              right: 20),
          child: ListView(children: <Widget>[
            SizedBox(
              height: 10,
            ),
            StyledDropdown<Item>(
              selectedValue: currentItem.value,
              items: buildMenuItems(items),
              onChanged: (value) {
                if (value != null) {
                  currentItem.value = value;
                  debugPrint("item updated to ${currentItem.value.name}");
                }
              },
              hintText: "Item Name",
              labelText: "Item Name",
              onAddPressed: () {
                isDialogOpen.value = true;
                showAddDialog(context, ref, 'Add item', 'Enter the item name',
                    ref.read(itemListProvider.notifier).add);
              },
            ),
            SearchableDropdown(),
            StyledDropdown<MortgageMaterial>(
              selectedValue: currentMortgageMaterial.value,
              items: buildMenuMortgageMaterials(mortgageMaterials),
              onChanged: (value) {
                if (value != null) {
                  currentMortgageMaterial.value = value;
                  debugPrint("item updated to ${currentItem.value.name}");
                }
              },
              hintText: "Mortgage Material",
              labelText: "Mortgage Material",
              onAddPressed: () {
                isDialogOpen.value = true;
                showAddDialog(
                    context,
                    ref,
                    'Add Mortgage Material',
                    'Enter the mortgage material',
                    ref.read(mortgageMaterialListProvider.notifier).add);
              },
            ),
            StyledTextField(
              textEditingController: depositorController,
              hintText: "Depositor Name",
              labelText: "Depositor Name",
            ),
            StyledTextField(
              textEditingController: addressController,
              hintText: "Address",
              labelText: "Address",
            ),
            StyledTextField(
              textEditingController: relationTypeController,
              hintText: "Relative Name",
              labelText: "Relative Name",
            ),
            StyledTextField(
              textEditingController: loanAmountController,
              hintText: "Loan Amount",
              labelText: "Loan Amount",
              keyboardType: TextInputType.number,
            ),
            StyledTextField(
              textEditingController: interestRateController,
              hintText: "Interest Rate",
              labelText: "Interest Rate",
              keyboardType: TextInputType.number,
            ),
            StyledDropdown<FamilyRelation>(
              selectedValue: currentFamilyRelation.value,
              items: buildMenuRelationTypes(familyRelations),
              onChanged: (value) {
                if (value != null) {
                  currentFamilyRelation.value = value;
                  debugPrint(
                      "item updated to ${currentFamilyRelation.value.name}");
                }
              },
              hintText: "Family Relation",
              labelText: "Family Relation",
              onAddPressed: () {
                isDialogOpen.value = true;
                showAddDialog(
                    context,
                    ref,
                    'Add Family Relation',
                    'Enter the family relation',
                    ref.read(familyRelationListProvider.notifier).add);
              },
            ),
            Consumer(builder: (context, ref, child) {
              return TextButton(
                onPressed: () async {
                  await ref.read(mortgageListProvider.notifier).add(
                      depositorController.text,
                      relationTypeController.text,
                      addressController.text,
                      _parseDouble(loanAmountController.text),
                      _parseDouble(interestRateController.text),
                      _parseDouble(weightController.text),
                      additionalDetailsController.text,
                      currentItem.value.id!,
                      currentFamilyRelation.value.id!,
                      currentMortgageMaterial.value.id!);
                  // Screen is left afterwards, no need to clear or update UI.
                  if (context.mounted) {
                    Navigator.pop(context);
                  }
                },
                style: TextButton.styleFrom(
                  foregroundColor: Colors.white, // Text color
                  // backgroundColor: color, // Button color
                  padding:
                      EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  // textStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                child: const Text('Save'),
              );
            }),
          ])),
      resizeToAvoidBottomInset: true,
    );
  }

  List<DropdownMenuItem<Item>> buildMenuItems(List<Item> items) => [
        for (var item in items)
          DropdownMenuItem(
              value: item,
              child: Text(
                item.name,
                style: const TextStyle(fontSize: 15.0, color: Colors.black),
              ))
      ];
  List<DropdownMenuItem<MortgageMaterial>> buildMenuMortgageMaterials(
          List<MortgageMaterial> mortgageMaterials) =>
      [
        for (var mortgageMaterial in mortgageMaterials)
          DropdownMenuItem(
              value: mortgageMaterial,
              child: Text(
                mortgageMaterial.name,
                style: const TextStyle(fontSize: 15.0, color: Colors.black),
              ))
      ];

  List<DropdownMenuItem<FamilyRelation>> buildMenuRelationTypes(
          List<FamilyRelation> familyRelations) =>
      [
        for (var familyRelation in familyRelations)
          DropdownMenuItem(
              value: familyRelation,
              child: Text(
                familyRelation.name,
                style: const TextStyle(fontSize: 15.0, color: Colors.black),
              ))
      ];

  Future<void> showAddDialog(
      BuildContext context,
      WidgetRef ref,
      String heading,
      String hintText,
      void Function(String text) onAddPressed) async {
    final controller = TextEditingController();
    await showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(heading),
        content: TextField(
          autofocus: true,
          decoration: InputDecoration(hintText: hintText),
          controller: controller,
        ),
        actions: [
          TextButton(
            child: const Text('Submit'),
            onPressed: () {
              onAddPressed(controller.text);
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
    // Clear text after dialog is dismissed.
    controller.clear();
  }
}
