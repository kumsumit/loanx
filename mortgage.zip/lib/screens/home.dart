import 'package:flutter/material.dart';
import 'package:mortgage/screens/mortgage_element.dart';
import 'package:mortgage/screens/mortgagelist_elements.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          SearchAppBar(),
          MortgageList()
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        key: const Key('add'),
        label: const Text('Add Mortgage'),
        heroTag: null,
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const MortgageInput()));
        },
      ),
    );
  }
}
