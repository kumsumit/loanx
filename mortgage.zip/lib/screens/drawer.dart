import 'package:flutter/material.dart';
import 'package:flutter_color_picker_plus/flutter_color_picker_plus.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/provider/provider.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      // backgroundColor: Theme.of(context).colorScheme.surface,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.secondary,
            ),
            child: Text(
              'Mortgage',
              style: TextStyle(
                  color: Theme.of(context).colorScheme.onSecondary,
                  fontSize: 24),
            ),
          ),
          ListTile(
            leading: Icon(Icons.info),
            title: Text('About',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurface,
                )),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    backgroundColor:
                        Theme.of(context).colorScheme.surfaceContainer,
                    title: Text(
                      'About',
                    ),
                    content: Text(
                      'This is a sample app demonstrating a Flutter Drawer with persistent storage for font size and displaying app version.',
                    ),
                    contentTextStyle: TextStyle(
                        color: Theme.of(context).colorScheme.inverseSurface),
                    actions: [
                      OutlinedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text(
                          'OK',
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
          ListTile(
              leading: Icon(Icons.color_lens),
              title: Text('Change App Color',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface,
                  )),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    backgroundColor:
                        Theme.of(context).colorScheme.surfaceContainer,
                    title: const Text('Pick a color!'),
                    content: SingleChildScrollView(
                      child: Column(
                        children: [
                          Consumer(builder: (context, ref, child) {
                            final color = ref.watch(pickerColorProvider);
                            return ColorPicker(
                              pickerColor: Color(color),
                              onColorChanged:
                                  ref.read(pickerColorProvider.notifier).set,
                            );
                          }),
                          Consumer(builder: (context, ref, child) {
                            return OutlinedButton(
                                onPressed: () async {
                                  await ref
                                      .read(appColorProvider.notifier)
                                      .setFromLogo();
                                  if (context.mounted) {
                                    Navigator.pop(context);
                                  }
                                },
                                child: Text("Set Logo Color"));
                          })
                        ],
                      ),
                    ),
                    actions: <Widget>[
                      Consumer(builder: (context, ref, child) {
                        return ElevatedButton(
                          child: const Text('Got it'),
                          onPressed: () {
                            ref.read(appColorProvider.notifier).set();
                            Navigator.of(context).pop();
                          },
                        );
                      }),
                    ],
                  ),
                );
              }),
          ListTile(
            leading: Icon(Icons.text_fields),
            title: Text('Change Font Size',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurface,
                )),
            onTap: () {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    backgroundColor:
                        Theme.of(context).colorScheme.surfaceContainer,
                    title: Text('Change Font Size'),
                    content: SizedBox(
                      height: 200,
                      child: Column(
                        children: [
                          Consumer(builder: (context, ref, child) {
                            final sliderFontSize =
                                ref.watch(sliderFontSizeProvider);
                            return Slider(
                              value: sliderFontSize,
                              min: 10.0,
                              max: 30.0,
                              divisions: 20,
                              label: sliderFontSize.round().toString(),
                              onChanged: (value) {
                                ref
                                    .read(sliderFontSizeProvider.notifier)
                                    .set(value);
                              },
                            );
                          }),
                          Consumer(builder: (context, ref, child) {
                            return Text(
                              "Mortgage",
                              style: TextStyle(
                                  fontSize: ref.watch(sliderFontSizeProvider)),
                            );
                          })
                        ],
                      ),
                    ),
                    actions: [
                      Consumer(builder: (context, ref, child) {
                        return TextButton(
                          onPressed: () {
                            ref.read(fontSizeProvider.notifier).set();
                            Navigator.of(context).pop();
                          },
                          child: Text('OK',
                              style: TextStyle(
                                  fontSize: Theme.of(context)
                                      .textTheme
                                      .bodyMedium!
                                      .fontSize)),
                        );
                      }),
                    ],
                  );
                },
              );
            },
          ),
          Consumer(builder: (context, ref, child) {
            return ListTile(
              leading: Icon(Icons.brightness_6),
              title: Text('Change Theme',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface,
                  )),
              onTap: ref.read(themeModeManagerProvider.notifier).set,
            );
          }),
          ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('App Version',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurface,
                )),
            trailing: Consumer(builder: (context, ref, child) {
              return ref.watch(appVersionProvider).when(
                  data: (appVersion) {
                    return Text(appVersion,
                        style: TextStyle(
                            fontSize: Theme.of(context)
                                .textTheme
                                .bodyMedium!
                                .fontSize));
                  },
                  error: (obj, trace) {
                    return Text("An error occurred");
                  },
                  loading: () => Text("..."));
            }),
          ),
        ],
      ),
    );
  }
}
