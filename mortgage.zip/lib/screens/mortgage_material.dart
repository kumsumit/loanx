import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/provider/provider.dart';

class MortgageMaterialView extends HookWidget {
  const MortgageMaterialView({super.key});

  @override
  Widget build(BuildContext context) {
    final mortgageMaterialController = useTextEditingController();
    return Scaffold(
      body: Consumer(builder: (context, ref, child) {
        final mortgageMaterials = ref.watch(mortgageMaterialListProvider);
        return ListView.builder(
          itemCount: mortgageMaterials.length,
          itemBuilder: (context, index) => ListTile(
            title: Text(mortgageMaterials[index].name),
          ),
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final dialog = await showDialog(
            context: context,
            builder: (BuildContext context) => AlertDialog(
              title: const Text('Add Mortgage Type'),
              content: TextField(
                autofocus: true,
                decoration:
                    const InputDecoration(hintText: 'Enter the Mortgage Type'),
                controller: mortgageMaterialController,
              ),
              actions: [
                Consumer(builder: (context, ref, child) {
                  return TextButton(
                    child: const Text('Submit'),
                    onPressed: () {
                      ref
                          .read(mortgageMaterialListProvider.notifier)
                          .add(mortgageMaterialController.text);
                      Navigator.of(context).pop();
                    },
                  );
                }),
              ],
            ),
          );
          // Clear text after dialog is dismissed.
          mortgageMaterialController.clear();
          return dialog;
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
