import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/db/mortgage.dart';
import 'package:mortgage/widget/heart_overlay.dart';
import 'package:mortgage/provider/provider.dart';
import 'package:mortgage/screens/mortgage_details_page.dart';
import 'package:mortgage/screens/mortgage_element.dart';
import 'package:mortgage/utils.dart';

/// Displays the current list of tasks by listening to a stream.
///
/// Each task has a check button to mark it completed and an edit button to
/// update it. A task can also be swiped away to remove it.
class MortgageList extends ConsumerWidget {
  const MortgageList({super.key});

  Dismissible _itemBuilder(BuildContext context, int index, WidgetRef ref,
          List<Mortgage> mortgages) =>
      Dismissible(
        background: ColoredBox(
          color: Colors.red,
        ),
        key: UniqueKey(), //Key('dismissed_$index'),
        onDismissed: (direction) {
          // Remove the task from the store.
          ref.read(mortgageListProvider.notifier).delete(mortgages[index].id!);
          // List updated via watched query stream.
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.only(bottom: 0, right: 70, left: 70),
              padding: const EdgeInsets.all(5),
              duration: const Duration(milliseconds: 800),
              content: Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                      height: 35,
                      child:
                          Text('Mortgage ${mortgages[index].id} deleted')))));
        },
        child: Row(
          children: <Widget>[
            Consumer(builder: (context, ref, child) {
              return Checkbox(
                  value: mortgages[index].isFinished(),
                  onChanged: (bool? value) async {
                    mortgages[index].toggleFinished();
                    ref
                        .read(mortgageListProvider.notifier)
                        .update(mortgages[index]);
                  });
            }),
            Expanded(
              child: DecoratedBox(
                decoration: const BoxDecoration(
                    border: Border(bottom: BorderSide(color: Colors.black12))),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 18.0, horizontal: 10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        '${mortgages[index].depositorName} (tag: ${mortgages[index].itemId})',
                        style: mortgages[index].isFinished()
                            ? const TextStyle(
                                color: Colors.grey,
                                decoration: TextDecoration.lineThrough)
                            : const TextStyle(fontSize: 15.0),
                        // Provide a Key for the integration test
                        key: Key('list_item_$index'),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 5.0),
                        child: Text(
                          mortgages[index].getStateText(),
                          style: const TextStyle(
                            fontSize: 12.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            TextButton(
                child: const Text('Edit'),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => MortgageInput(
                                mortgage: mortgages[index],
                              ) //passing Id to access Mortgage in new page
                          ));
                }),
          ],
        ),
      );

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mortgages = ref.watch(mortgageListProvider);
    return Expanded(
        child:  ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      itemCount: mortgages.length,
                      itemBuilder: (c, i) {
                        return _itemBuilder(c, i, ref, mortgages);
                      }));
  }
}

class SearchAppBar extends HookWidget {
  const SearchAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    final filter = useState<int>(1);
    return Padding(
      padding: EdgeInsets.only(left: 20.0, bottom: 10.0),
      child: Center(
          child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
              child: filter.value == 1
                  ? Consumer(builder: (context, ref, child) {
                      return TypeAheadField<Mortgage>(
                        suggestionsCallback: (searchTerm) =>
                            suggestionsCallback(searchTerm, filter.value, ref),
                        builder: (context, controller, focusNode) {
                          return TextField(
                              controller: controller,
                              focusNode: focusNode,
                              autofocus: true,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                labelText: 'Search Mortgage',
                                // icon: Icon(Icons.search),
                              ));
                        },
                        itemBuilder: (context, mortgage) {
                          final m =  ref.watch(itemListProvider);
                          return ListTile(
                            title: Text(mortgage.depositorName),
                            leading: Text( m.firstWhere((mo)=>mo.id == mortgage.itemId).name),
                          );
                        },
                        onSelected: (mortgage) {
                          Navigator.of(context).push<void>(
                            MaterialPageRoute(
                              builder: (context) =>
                                  MortgageDetails(mortgage: mortgage),
                            ),
                          );
                        },
                      );
                    })
                  : SizedBox()),
          PopupMenuButton<int>(
            icon: Icon(Icons.filter_alt_outlined),
            onSelected: (value) {
              // if(value==3){

              // } else if(){

              // }
              filter.value = value;
            },
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem<int>(
                  value: 1,
                  child: Text('Depositor Name'),
                ),
                PopupMenuItem<int>(
                  value: 2,
                  child: Text('Relative Name'),
                ),
                PopupMenuItem<int>(value: 3, child: Text('Date Of Loan')),
                PopupMenuItem<int>(value: 4, child: Text('Date Range Of Loan')),
                PopupMenuItem<int>(value: 5, child: Text('Mortgage Type')),
                PopupMenuItem<int>(value: 6, child: Text('Item Type')),
              ];
            },
          ),
          IconButton(
              onPressed: () async => await uploadToGoogleDrive(context),
              icon: Icon(Icons.upload)),
          IconButton(
              onPressed: listBackupFiles,
              icon: Icon(Icons.view_comfortable_outlined)),
          IconButton(
            onPressed: () {
              showOverlay(context);
            },
            icon: Icon(Icons.favorite),
          ),
        ],
      )),
    );
  }

  void showOverlay(BuildContext context) {
    OverlayState overlayState = Overlay.of(context);
    OverlayEntry overlayEntry = OverlayEntry(
      builder: (context) => GestureDetector(
        onDoubleTap: () {
          debugPrint("I am double pressed");
        },
        child: Stack(
          children: [
            Positioned(
              left: 50,
              top: 100,
              child: HeartShapeOverlay(),
            ),
          ],
        ),
      ),
    );
    overlayState.insert(overlayEntry);
    // Future.delayed(Duration(seconds: 3), () {
    //   overlayEntry.remove();
    // });
  }

  suggestionsCallback(String searchTerm, int filter, WidgetRef ref) {
    switch (filter) {
      case 1:
        // ref.read(objectBoxProvider).searchMortgagesByDepositorName(searchTerm);
        break;
      case 2:
        // ref.read(objectBoxProvider).searchMortgagesByRelativeName(searchTerm);
        break;
      case 3:
        debugPrint('The command is APPROVED');
        break;
      case 4:
        debugPrint('The command is DENIED');
        break;
      case 5:
        debugPrint('The command is OPEN');
        break;
      default:
        debugPrint('Unknown command');
    }
  }
}
