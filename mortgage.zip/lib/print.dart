// dependencies:
//   esc_pos_utils: ^1.1.0
//   esc_pos_printer: ^4.1.0

// import 'package:esc_pos_utils/esc_pos_utils.dart';
// import 'package:esc_pos_printer/esc_pos_printer.dart';

// void printReceipt() {
//   final printer = EscPosPrinter();
//   final receipt = EscPosPrintReceipt(
//     text: 'Hello, this is a test receipt!',
//     alignment: Alignment.center,
//   );

//   printer.connect();
//   printer.printReceipt(receipt);
//   printer.disconnect();
// }

//******************************************************************* */

// For PDF Printing

// dependencies:
//   flutter:
//     sdk: flutter
//   printing: ^5.9.0
//   pdf: ^3.6.0

// import 'dart:typed_data';
// import 'package:flutter/material.dart';
// import 'package:pdf/pdf.dart';
// import 'package:pdf/widgets.dart' as pw;
// import 'package:printing/printing.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(title: Text('Flutter PDF Printing')),
//         body: Center(
//           child: ElevatedButton(
//             onPressed: () => printDocument(),
//             child: Text('Print PDF'),
//           ),
//         ),
//       ),
//     );
//   }

//   Future<void> printDocument() async {
//     final pdf = pw.Document();
//     pdf.addPage(
//       pw.Page(
//         build: (pw.Context context) => pw.Center(
//           child: pw.Text('Hello World!'),
//         ),
//       ),
//     );

//     final Uint8List bytes = await pdf.save();
//     await Printing.layoutPdf(
//       onLayout: (PdfPageFormat format) async => bytes,
//     );
//   }
// }
