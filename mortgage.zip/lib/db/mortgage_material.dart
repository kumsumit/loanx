class MortgageMaterialFields {
  static final List<String> values = [id, name];

  static final String id = 'id';
  static final String name = 'name';
}

class MortgageMaterial {
  static final String tableName = 'mortgage_materials';
  final int? id;
  final String name;

  const MortgageMaterial({
    this.id,
    required this.name,
  });

  MortgageMaterial copy({
    int? id,
    String? name,
  }) =>
      MortgageMaterial(
        id: id ?? this.id,
        name: name ?? this.name,
      );

  static MortgageMaterial fromJson(Map<String, Object?> json) => MortgageMaterial(
        id: json[MortgageMaterialFields.id] as int,
        name: json[MortgageMaterialFields.name] as String,
      );

  Map<String, Object?> toJson() => {
        MortgageMaterialFields.id: id,
        MortgageMaterialFields.name: name,
      };
}