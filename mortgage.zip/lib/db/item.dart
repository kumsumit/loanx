class ItemFields {
  static final List<String> values = [id, name];

  static final String id = 'id';
  static final String name = 'name';
}

class Item {
  static final String tableName = 'items';
  final int? id;
  final String name;

  const Item({
    this.id,
    required this.name,
  });

  Item copy({
    int? id,
    String? name,
  }) =>
      Item(
        id: id ?? this.id,
        name: name ?? this.name,
      );

  static Item fromJson(Map<String, Object?> json) => Item(
        id: json[ItemFields.id] as int,
        name: json[ItemFields.name] as String,
      );

  Map<String, Object?> toJson() => {
        ItemFields.id: id,
        ItemFields.name: name,
      };
}
