class FamilyRelationFields {
  static final List<String> values = [id, name];

  static final String id = 'id';
  static final String name = 'name';
}

class FamilyRelation {
  static final String tableName = 'family_relations';
  final int? id;
  final String name;

  const FamilyRelation({
    this.id,
    required this.name,
  });

  FamilyRelation copy({
    int? id,
    String? name,
  }) =>
      FamilyRelation(
        id: id ?? this.id,
        name: name ?? this.name,
      );

  static FamilyRelation fromJson(Map<String, Object?> json) => FamilyRelation(
        id: json[FamilyRelationFields.id] as int,
        name: json[FamilyRelationFields.name] as String,
      );

  Map<String, Object?> toJson() => {
        FamilyRelationFields.id: id,
        FamilyRelationFields.name: name,
      };
}
