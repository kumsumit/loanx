import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SuggestionOverlayDemo(),
    );
  }
}

class SuggestionOverlayDemo extends StatefulWidget {
  const SuggestionOverlayDemo({super.key});

  @override
  SuggestionOverlayDemoState createState() => SuggestionOverlayDemoState();
}

class SuggestionOverlayDemoState extends State<SuggestionOverlayDemo> {
  final TextEditingController _controller = TextEditingController();
  OverlayEntry? _overlayEntry;
  final List<String> _suggestions = [
    'Suggestion 1',
    'Suggestion 2',
    'Suggestion 3'
  ];
  DateTimeRange? _selectedDateRange;

  void _showOverlay(BuildContext context) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final size = renderBox.size;
    final offset = renderBox.localToGlobal(Offset.zero);

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        left: offset.dx,
        top: offset.dy + size.height,
        width: size.width,
        child: Material(
          elevation: 4.0,
          child: ListView(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            children: _suggestions.map((suggestion) {
              return ListTile(
                title: Text(suggestion),
                onTap: () {
                  _controller.text = suggestion;
                  _overlayEntry?.remove();
                  _overlayEntry = null;
                },
              );
            }).toList(),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(_overlayEntry!);
  }

  Future<void> _selectDateRange(BuildContext context) async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      initialDateRange: _selectedDateRange,
    );
    if (picked != null && picked != _selectedDateRange) {
      setState(() {
        _selectedDateRange = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Suggestion Overlay with Date Range Picker'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter text',
              ),
              onChanged: (value) {
                if (_overlayEntry != null) {
                  _overlayEntry?.remove();
                  _overlayEntry = null;
                }
                if (value.isNotEmpty) {
                  _showOverlay(context);
                }
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _selectDateRange(context),
              child: Text('Select Date Range'),
            ),
            SizedBox(height: 20),
            Text(
              _selectedDateRange == null
                  ? 'No date range selected'
                  : 'Selected range: ${DateFormat('MM/dd/yyyy').format(_selectedDateRange!.start)} - ${DateFormat('MM/dd/yyyy').format(_selectedDateRange!.end)}',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
