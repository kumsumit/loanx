import 'dart:io';
import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
// import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:path/path.dart';
import 'package:googleapis_auth/googleapis_auth.dart' as auth show AuthClient;
import 'package:path_provider/path_provider.dart';

// const color = Color.fromARGB(255, 212, 175, 55);
// final clientId =
//     "1074342328106-8tujabe1la2ekkg20nkod1867knldn6n.apps.googleusercontent.com";
final FirebaseAuth _auth = FirebaseAuth.instance;
final GoogleSignIn _googleSignIn = GoogleSignIn(
    // serverClientId: clientId,
    scopes: [drive.DriveApi.driveAppdataScope]);

Future<String> createAppFolder(drive.DriveApi driveApi) async {
  var folder = drive.File();
  folder.name = "Mortgage";
  folder.parents = ['appDataFolder'];
  folder.mimeType = 'application/vnd.google-apps.folder';
  var folderCreation = await driveApi.files.create(folder);
  debugPrint('Created folder ID: ${folderCreation.id}');
  return folderCreation.id!;
}

Future<String?> getFolderId() async {
  var googleSignIn =
      GoogleSignIn.standard(scopes: [drive.DriveApi.driveAppdataScope]);
  var googleUser = await googleSignIn.signIn();
  var authHeaders = await googleUser?.authHeaders;
  var client = GoogleHttpClient(authHeaders!);
  var driveApi = drive.DriveApi(client);
  var response = await driveApi.files.list(
    spaces: 'appDataFolder',
    q: "name = 'Mortgage' and mimeType = 'application/vnd.google-apps.folder'",
  );

  if (response.files != null && response.files!.isNotEmpty) {
    return response.files!.first.id;
  } else {
    return null;
  }
}

Future<void> uploadToGoogleDrive(BuildContext context) async {
  try {
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
    if (googleUser != null) {
      final auth.AuthClient? client = await _googleSignIn.authenticatedClient();
      if (client != null) {
        // final a = Color.fromARGB(255, 66, 51, 1);
        File file = File(
            "/data/user/0/com.kumpali.mortgage/app_flutter/jewellery/data.mdb");
        file = await file.copy(
            "/data/user/0/com.kumpali.mortgage/app_flutter/jewellery/backup.mdb");
        // join(
        //       (await getApplicationDocumentsDirectory()).path, "jewellery");
        drive.File fileToUpload = drive.File();
        DateTime now = DateTime.now();
        fileToUpload.name =
            "${now.toIso8601String()}_${basename(file.absolute.path)}";
        fileToUpload.parents = ['appDataFolder'];
        final driveApi = drive.DriveApi(client);
        await driveApi.files.create(fileToUpload,
            uploadMedia: drive.Media(file.openRead(), file.lengthSync()));
        if (file.existsSync()) {
          file.deleteSync();
        }
      }
    } else {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Failed to sign in !!")));
      }
    }
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
}

Future<User?> signInWithGoogle() async {
  final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
  final GoogleSignInAuthentication googleAuth =
      await googleUser!.authentication;
  final AuthCredential credential = GoogleAuthProvider.credential(
    accessToken: googleAuth.accessToken,
    idToken: googleAuth.idToken,
  );
  final UserCredential userCredential =
      await _auth.signInWithCredential(credential);
  return userCredential.user;
}

class GoogleHttpClient extends IOClient {
  final Map<String, String> _headers;
  GoogleHttpClient(this._headers) : super();

  @override
  Future<IOStreamedResponse> send(http.BaseRequest request) =>
      super.send(request..headers.addAll(_headers));

  @override
  Future<http.Response> head(url, {Map<String, String>? headers}) =>
      super.head(url, headers: headers?..addAll(_headers));
}

// Function to upload a file
// Future<void> uploadFile(File file) async {
//   final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
//   // final authHeaders = await _googleSignIn.currentUser!.authHeaders;
//   if (googleUser != null) {
//     final authHeaders = await googleUser.authHeaders;
//     final authenticateClient = GoogleHttpClient(authHeaders);
//     final driveApi = drive.DriveApi(authenticateClient);

//     var media = drive.Media(file.openRead(), file.lengthSync());
//     var driveFile = drive.File();
//     driveFile.name = basename(file.absolute.path);
//     driveFile.parents = ['appDataFolder'];
//     await driveApi.files.create(driveFile, uploadMedia: media);
//   }
// }

// Future<void> pickFile() async {
//   FilePickerResult? result = await FilePicker.platform.pickFiles();
//   if (result != null) {
//     File file = File(result.files.single.path!);
//     await uploadFile(file);
//   }
// }

Future<void> listBackupFiles() async {
  // var googleSignIn = GoogleSignIn.standard(scopes: [drive.DriveApi.driveAppdataScope]);
  var googleUser = await _googleSignIn.signIn();
  var authHeaders = await googleUser?.authHeaders;
  var client = GoogleHttpClient(authHeaders!);
  var driveApi = drive.DriveApi(client);

  var response = await driveApi.files.list(spaces: 'appDataFolder');
  response.files?.forEach((file) {
    debugPrint('Found file: ${file.name} (${file.id})');
  });
}

// Future<void> _loginWithGoogle() async {
//   final storage = FlutterSecureStorage();

//        signedIn = await storage.read(key: "signedIn") == "true" ? true : false;
//        googleSignIn.onCurrentUserChanged
//            .listen((GoogleSignInAccount googleSignInAccount) async {
//          if (googleSignInAccount != null) {
//            _afterGoogleLogin(googleSignInAccount);
//          }
//        });
//        if (signedIn) {
//          try {
//            googleSignIn.signInSilently().whenComplete(() => () {});
//          } catch (e) {
//            storage.write(key: "signedIn", value: "false").then((value) {
//              setState(() {
//                signedIn = false;
//              });
//            });
//          }
//        } else {
//          final GoogleSignInAccount googleSignInAccount =
//              await googleSignIn.signIn();
//          _afterGoogleLogin(googleSignInAccount);
//        }
//      }

//      Future<void> _afterGoogleLogin(GoogleSignInAccount gSA) async {
//        googleSignInAccount = gSA;
//        final GoogleSignInAuthentication googleSignInAuthentication =
//            await googleSignInAccount.authentication;

//        final AuthCredential credential = GoogleAuthProvider.getCredential(
//          accessToken: googleSignInAuthentication.accessToken,
//          idToken: googleSignInAuthentication.idToken,
//        );

//        final AuthResult authResult = await _auth.signInWithCredential(credential);
//        final FirebaseUser user = authResult.user;

//        assert(!user.isAnonymous);
//        assert(await user.getIdToken() != null);

//        final FirebaseUser currentUser = await _auth.currentUser();
//        assert(user.uid == currentUser.uid);

//        print('signInWithGoogle succeeded: $user');

//        storage.write(key: "signedIn", value: "true").then((value) {
//          setState(() {
//            signedIn = true;
//          });
//        });
//      }

double? getFontSize(context) =>
    Theme.of(context).textTheme.bodyMedium!.fontSize;

bool isDark(context) => Theme.of(context).brightness == Brightness.dark;
