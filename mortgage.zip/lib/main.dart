import 'package:fastdb/fastdb.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:mortgage/database_helper.dart';
import 'package:mortgage/provider/provider.dart';
import 'package:mortgage/screens/dashboard.dart';

void main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  await FastDB.init();
  final database = await DatabaseHelper.instance.database;
  await Firebase.initializeApp();
  FlutterNativeSplash.remove();
  runApp(ProviderScope(
    overrides: [databaseProvider.overrideWithValue(database)],
    child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer(builder: (BuildContext context, ref, Widget? child) {
      final themeMode = ref.watch(themeModeManagerProvider);
      final fontSize = ref.watch(fontSizeProvider);
      final appColor = ref.watch(appColorProvider);
      return MaterialApp(
          themeMode: themeMode,
          theme: ThemeData(
            colorSchemeSeed: Color(appColor),
            textTheme: TextTheme(bodyMedium: TextStyle(fontSize: fontSize)),
          ),
          darkTheme: ThemeData(
            colorSchemeSeed: Color(appColor),
            brightness: Brightness.dark,
            textTheme: TextTheme(bodyMedium: TextStyle(fontSize: fontSize)),
          ),
          debugShowCheckedModeBanner: false,
          home: DashBoard());
    });
  }
}
