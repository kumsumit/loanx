import 'package:flutter/material.dart';

class StarOverlay extends StatelessWidget {
  const StarOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: StarPainter(),
    );
  }
}

class StarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()
      ..color = Colors.yellow
      ..style = PaintingStyle.fill;

    var path = Path();
    double width = size.width;
    double halfWidth = size.width / 2;
    double height = size.height;
    double halfHeight = size.height / 2;

    path.moveTo(halfWidth, 0);
    path.lineTo(halfWidth * 0.62, halfHeight * 0.62);
    path.lineTo(0, halfHeight * 0.62);
    path.lineTo(halfWidth * 0.38, height);
    path.lineTo(halfWidth * 0.62, height * 0.62);
    path.lineTo(width, height * 0.62);
    path.lineTo(halfWidth * 1.38, height);
    path.lineTo(halfWidth, halfHeight * 0.62);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
