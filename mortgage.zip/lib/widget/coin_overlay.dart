import 'package:flutter/material.dart';

class CoinOverlay extends StatelessWidget {
  const CoinOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: CoinPainter(),
      child: SizedBox(
        width: 100,
        height: 100,
        child: Align(
          alignment: Alignment.center,
          child: Text(
            '\u{1FA99}', // Unicode for gold coin
            style: TextStyle(fontSize: 50),
          ),
        ),
      ),
    );
  }
}

class CoinPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()
      ..color = Color(0xFFFFD700) // Gold color
      ..style = PaintingStyle.fill;

    var path = Path();
    path.addOval(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
