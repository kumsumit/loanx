import 'package:flutter/material.dart';
import 'package:mortgage/widget/callout_overlay.dart';

class SearchableDropdown extends StatefulWidget {
  const SearchableDropdown({super.key});

  @override
  SearchableDropdownState createState() => SearchableDropdownState();
}

class SearchableDropdownState extends State<SearchableDropdown>
    with SingleTickerProviderStateMixin {
  List<String> items = [
    'Apple',
    'Banana',
    'Cherry',
    'Date',
    'Elderberry',
    'Fig',
    'Grape'
  ];
  List<String> filteredItems = [];
  String? selectedItem;
  TextEditingController searchController = TextEditingController();
  OverlayEntry? overlayEntry;
  LayerLink layerLink = LayerLink();
  FocusNode focusNode = FocusNode();
  AnimationController? animationController;
  Animation<Offset>? animationOffset;

  @override
  void initState() {
    super.initState();
    filteredItems = items;
    focusNode.addListener(() {
      if (focusNode.hasFocus) {
        showOverlay();
      } else {
        hideOverlay();
      }
    });

    animationController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 400));
    animationOffset = Tween<Offset>(begin: Offset(0, -0.2), end: Offset(0, 0))
        .animate(CurvedAnimation(
            parent: animationController!, curve: Curves.easeInOut));
  }

  void showOverlay() {
    if (overlayEntry != null) {
      overlayEntry!.remove();
    }
    overlayEntry = createOverlayEntry();
    Overlay.of(context).insert(overlayEntry!);
    animationController?.forward();
  }

  OverlayEntry createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;
    return OverlayEntry(
      builder: (context) => GestureDetector(
        onTap: () {
          hideOverlay();
          focusNode.unfocus();
        },
        behavior: HitTestBehavior.translucent,
        child: Stack(
          children: [
            Positioned(
              width: size.width,
              child: Center(
                child: CompositedTransformFollower(
                  link: layerLink,
                  showWhenUnlinked: false,
                  offset: Offset(0, 50),
                  child: SlideTransition(
                    position: animationOffset!,
                    child: CustomPaint(
                      painter: CalloutBoxPainter(),
                      child: Material(
                        elevation: 12.0,
                        color: Colors.amber,
                        // shape:  DropdownShapeBorder(
                        //       radius: BorderRadius.circular(12)
                        //     ),
                        // borderRadius: BorderRadius.circular(12),
                        // child:
                        // DecoratedBox(
                        //   decoration: ShapeDecoration(
                        //     shape: DropdownShapeBorder(
                        //       radius: BorderRadius.circular(12)
                        //     ),
                        //     gradient: LinearGradient(
                        //       colors: [
                        //         Colors.white,
                        //         Colors.grey[200]!
                        //       ], // Minimalist gradient
                        //       begin: Alignment.topCenter,
                        //       end: Alignment.bottomCenter,
                        //     ),
                        // border: Border.all(color: Colors.blueAccent.withOpacity(0.7)),
                        // borderRadius: BorderRadius.circular(12),
                        // boxShadow: [
                        //   BoxShadow(
                        //     color: Colors.black26,
                        //     blurRadius: 10,
                        //     spreadRadius: 1,
                        //     offset: Offset(0, 5),
                        //   ),
                        // ],
                        // ),
                        child: ListView.builder(
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          itemCount: filteredItems.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              leading: Icon(Icons.check_circle,
                                  color: Colors.blueAccent),
                              title: Text(
                                filteredItems[index],
                                style: TextStyle(
                                  fontFamily: 'RobotoMono', // More stylish font
                                  color: Colors.blueAccent,
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  letterSpacing: 0.5,
                                  shadows: [
                                    Shadow(
                                      blurRadius: 4.0,
                                      color: Colors.black38,
                                      offset: Offset(1.0, 1.0),
                                    ),
                                  ],
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  selectedItem = filteredItems[index];
                                  searchController.text = selectedItem!;
                                  hideOverlay();
                                  focusNode.unfocus();
                                });
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                  // ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void hideOverlay() {
    animationController?.reverse().then((_) {
      overlayEntry?.remove();
      overlayEntry = null;
    });
  }

  @override
  void dispose() {
    animationController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: layerLink,
      child: Padding(
        padding: EdgeInsets.only(top: 8.0, left: 8.0, right: 8.0),
        // padding: const EdgeInsets.all(8.0),
        child: TextField(
          controller: searchController,
          focusNode: focusNode,
          decoration: InputDecoration(
            hintText: 'Search...',
            hintStyle: TextStyle(color: Colors.blueAccent),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            suffixIcon: Icon(Icons.search, color: Colors.blueAccent),
          ),
          style: TextStyle(color: Colors.blueAccent, fontFamily: 'RobotoMono'),
          onChanged: (value) {
            setState(() {
              filteredItems = items
                  .where((item) =>
                      item.toLowerCase().contains(value.toLowerCase()))
                  .toList();
              if (filteredItems.isNotEmpty) {
                showOverlay();
              } else {
                hideOverlay();
              }
            });
          },
        ),
      ),
    );
  }
}

class DropdownBorderPainter extends CustomPainter {
  // @override
  // void paint(Canvas canvas, Size size) {
  //   final paint = Paint()
  //     ..color = Colors.blueAccent
  //     ..style = PaintingStyle.stroke
  //     ..strokeWidth = 2.0;

  //   final rect = Rect.fromLTWH(0, 0, size.width, size.height);
  //   final rrect = RRect.fromRectAndRadius(rect, Radius.circular(12));

  //   canvas.drawRRect(rrect, paint);
  // }

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blueAccent
      ..style = PaintingStyle.fill
      ..shader = LinearGradient(
        colors: [Colors.blue, Colors.lightBlueAccent],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final path = Path()
      ..moveTo(20, 0)
      ..lineTo(size.width - 20, 0)
      ..quadraticBezierTo(size.width, 0, size.width, 20)
      ..lineTo(size.width, size.height - 20)
      ..quadraticBezierTo(size.width, size.height, size.width - 20, size.height)
      ..lineTo(30, size.height)
      ..lineTo(25, size.height + 20) // Arrow part
      ..lineTo(20, size.height)
      ..lineTo(20, size.height)
      ..lineTo(20, size.height)
      ..lineTo(20, size.height)
      ..lineTo(20, size.height - 20)
      ..quadraticBezierTo(0, size.height, 0, size.height - 20)
      ..lineTo(0, 20)
      ..quadraticBezierTo(0, 0, 20, 0)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}
