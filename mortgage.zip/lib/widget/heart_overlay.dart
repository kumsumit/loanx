import 'package:flutter/material.dart';

class HeartShapeOverlay extends StatelessWidget {
  const HeartShapeOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: HeartPainter(),
      child: Align(
        alignment: Alignment.center,
        child: SizedBox(
          width: 200,
          height: 200,
          child: Text(
            '❤️',
            style: TextStyle(fontSize: 50, color: Colors.red),
          ),
        ),
      ),
    );
  }
}

class HeartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.fill;

    var path = Path();
    path.moveTo(size.width / 2, size.height / 4);
    path.cubicTo(0, size.height / 4, 0, 3 * size.height / 4, size.width / 2,
        size.height);
    path.cubicTo(size.width, 3 * size.height / 4, size.width, size.height / 4,
        size.width / 2, size.height / 4);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
