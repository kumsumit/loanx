import 'package:flutter/material.dart';

class CalloutBoxOverlay extends StatelessWidget {
  const CalloutBoxOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: CalloutBoxPainter(),
      child: SizedBox(
        width: 200,
        height: 100,
        child: Align(
          alignment: Alignment.center,
          child: Text(
            'Callout Box',
            style: TextStyle(fontSize: 18, color: Colors.black),
          ),
        ),
      ),
    );
  }
}

class CalloutBoxPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    var path = Path();
    path.moveTo(size.width / 2 - 10, 0);
    path.lineTo(size.width / 2, -10);
    path.lineTo(size.width / 2 + 10, 0);
    path.close();

    canvas.drawPath(path, paint);

    path = Path();
    path.addRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Radius.circular(10),
    ));
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
