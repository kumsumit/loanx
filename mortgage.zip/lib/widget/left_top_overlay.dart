import 'package:flutter/material.dart';

class LeftTopCalloutBoxOverlay extends StatelessWidget {
  const LeftTopCalloutBoxOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: CalloutBoxPainter(),
      child: Container(
        width: 200,
        height: 100,
        alignment: Alignment.center,
        child: Text(
          'Callout Box',
          style: TextStyle(fontSize: 18, color: Colors.black),
        ),
      ),
    );
  }
}

class CalloutBoxPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    var borderPaint = Paint()
      ..color = Colors.blue.shade900
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    // Drawing the enhanced arrow on the top left side and touching the callout
    var path = Path();
    path.moveTo(20, 0);
    path.lineTo(10, -10);
    path.lineTo(30, 0);
    path.close();

    canvas.drawPath(path, paint);
    canvas.drawPath(path, borderPaint);

    // Drawing the box
    path = Path();
    path.addRRect(RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 10, size.width, size.height - 10),
      Radius.circular(10),
    ));
    canvas.drawPath(path, paint);
    canvas.drawPath(path, borderPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
