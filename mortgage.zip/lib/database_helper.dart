import 'package:sqflite_sqlcipher/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  factory DatabaseHelper() => instance;
  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'mortgage.db');
    return await openDatabase(path, version: 1,
        onCreate: _onCreate, password: 'yourhgjgujjhjhjhsecure_passwordhfjffffhgf');
  }

  Future _onCreate(Database db, int version) async {
    await db.execute(
        '''
          CREATE TABLE items(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
          CREATE TABLE mortgageMaterials(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
          CREATE TABLE familyRelations(id INTEGER PRIMARY KEY, name TEXT UNIQUE);
          CREATE TABLE mortgage(id INTEGER PRIMARY KEY, depositorName TEXT UNIQUE, relativeName Text, address TEXT, 
          loanAmount REAL, interestRate REAL, weight REAL, additionalDetails TEXT, dateCreated TEXT, dateFinished TEXT);
        ''');
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }

}
