// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$appVersionHash() => r'4304956db232227fd516e60af9cef7bca0cd836e';

/// See also [appVersion].
@ProviderFor(appVersion)
final appVersionProvider = AutoDisposeFutureProvider<String>.internal(
  appVersion,
  name: r'appVersionProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$appVersionHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AppVersionRef = AutoDisposeFutureProviderRef<String>;
String _$themeModeManagerHash() => r'ae5fb9b62506231244ab89ee26dab3c1489fa6ab';

/// See also [ThemeModeManager].
@ProviderFor(ThemeModeManager)
final themeModeManagerProvider =
    NotifierProvider<ThemeModeManager, ThemeMode>.internal(
  ThemeModeManager.new,
  name: r'themeModeManagerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$themeModeManagerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ThemeModeManager = Notifier<ThemeMode>;
String _$fontSizeHash() => r'c922c5c40d72f396743af440b5ce52aea212e800';

/// See also [FontSize].
@ProviderFor(FontSize)
final fontSizeProvider = NotifierProvider<FontSize, double>.internal(
  FontSize.new,
  name: r'fontSizeProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$fontSizeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FontSize = Notifier<double>;
String _$sliderFontSizeHash() => r'6842db84e25d30a68276fbd6da10e83ee0071d27';

/// See also [SliderFontSize].
@ProviderFor(SliderFontSize)
final sliderFontSizeProvider =
    AutoDisposeNotifierProvider<SliderFontSize, double>.internal(
  SliderFontSize.new,
  name: r'sliderFontSizeProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sliderFontSizeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SliderFontSize = AutoDisposeNotifier<double>;
String _$appColorHash() => r'c502456c6403fc6b18c708cae9f09e1362b19c8e';

/// See also [AppColor].
@ProviderFor(AppColor)
final appColorProvider = NotifierProvider<AppColor, int>.internal(
  AppColor.new,
  name: r'appColorProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$appColorHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AppColor = Notifier<int>;
String _$pickerColorHash() => r'0d0bc2c23944b617d4185c09a2ef7849f548bb65';

/// See also [PickerColor].
@ProviderFor(PickerColor)
final pickerColorProvider =
    AutoDisposeNotifierProvider<PickerColor, int>.internal(
  PickerColor.new,
  name: r'pickerColorProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$pickerColorHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PickerColor = AutoDisposeNotifier<int>;
String _$authHash() => r'aef61221debf8d97acac9fbb759fc7bb056d15d7';

/// See also [Auth].
@ProviderFor(Auth)
final authProvider = AutoDisposeNotifierProvider<Auth, bool>.internal(
  Auth.new,
  name: r'authProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$authHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Auth = AutoDisposeNotifier<bool>;
String _$familyRelationListHash() =>
    r'2d76f1f1424103f2051445f426a2a8ab7624ae9a';

/// See also [FamilyRelationList].
@ProviderFor(FamilyRelationList)
final familyRelationListProvider = AutoDisposeNotifierProvider<
    FamilyRelationList, List<FamilyRelation>>.internal(
  FamilyRelationList.new,
  name: r'familyRelationListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$familyRelationListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$FamilyRelationList = AutoDisposeNotifier<List<FamilyRelation>>;
String _$mortgageMaterialListHash() =>
    r'c7c45ce64f162e5f54c62eadbf063b7b9d0b84c3';

/// See also [MortgageMaterialList].
@ProviderFor(MortgageMaterialList)
final mortgageMaterialListProvider = AutoDisposeNotifierProvider<
    MortgageMaterialList, List<MortgageMaterial>>.internal(
  MortgageMaterialList.new,
  name: r'mortgageMaterialListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$mortgageMaterialListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MortgageMaterialList = AutoDisposeNotifier<List<MortgageMaterial>>;
String _$itemListHash() => r'273ca47d591aeaa2ab8c183ba72f68f9c828ed12';

/// See also [ItemList].
@ProviderFor(ItemList)
final itemListProvider =
    AutoDisposeNotifierProvider<ItemList, List<Item>>.internal(
  ItemList.new,
  name: r'itemListProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$itemListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ItemList = AutoDisposeNotifier<List<Item>>;
String _$mortgageListHash() => r'ad89bf8eeb51506675ce569ab2b30df46c705380';

/// See also [MortgageList].
@ProviderFor(MortgageList)
final mortgageListProvider =
    AutoDisposeNotifierProvider<MortgageList, List<Mortgage>>.internal(
  MortgageList.new,
  name: r'mortgageListProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$mortgageListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MortgageList = AutoDisposeNotifier<List<Mortgage>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
