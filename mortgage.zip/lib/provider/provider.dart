import 'dart:io';
import 'package:fastdb/fastdb.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mortgage/database_helper.dart';
import 'package:mortgage/db/family_relation.dart';
import 'package:mortgage/db/item.dart';
import 'package:mortgage/db/mortgage.dart';
import 'package:mortgage/db/mortgage_material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:flutter_exif_rotation/flutter_exif_rotation.dart';
import 'package:sqflite_sqlcipher/sqlite_api.dart';
part 'provider.g.dart';

@Riverpod(keepAlive: true)
class ThemeModeManager extends _$ThemeModeManager {
  @override
  ThemeMode build() {
    return ThemeMode.values[FastDB.getInt('themeMode') ?? ThemeMode.system.index];
  }

  void set() {
    state = state == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    FastDB.putByte('themeMode', state.index);
  }
}

@Riverpod(keepAlive: true)
class FontSize extends _$FontSize {
  @override
  double build() {
    return FastDB.getFloat("fontSize") ?? 16.0;
  }

  void set() {
    state = ref.read(sliderFontSizeProvider);
    FastDB.putFloat("fontSize", state);
  }
}

@riverpod
class SliderFontSize extends _$SliderFontSize {
  @override
  double build() => FastDB.getFloat("fontSize") ?? 16.0;

  void set(double newValue) {
    state = newValue;
  }
}

@Riverpod(keepAlive: true)
class AppColor extends _$AppColor {
  @override
  int build() => FastDB.getPositiveLong("appColor") ?? 0xffD4AF37;

  void set() {
    state = ref.read(pickerColorProvider);
    FastDB.putPositiveLong("appColor", state);
  }

  Future<void> setFromLogo() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      File rotatedImage =
          await FlutterExifRotation.rotateImage(path: image.path);
      final scheme = await ColorScheme.fromImageProvider(
        provider: FileImage(rotatedImage),
        brightness: Brightness.light,
      );
      ref.read(pickerColorProvider.notifier).set(scheme.primary);
      set();
    } else {
      final LostDataResponse response = await picker.retrieveLostData();
      if (!response.isEmpty) {
        final List<XFile>? files = response.files;
        if (files != null) {
          File rotatedImage =
              await FlutterExifRotation.rotateImage(path: files.first.path);
          final scheme = await ColorScheme.fromImageProvider(
            provider: FileImage(rotatedImage),
            brightness: Brightness.light,
          );
          ref.read(pickerColorProvider.notifier).set(scheme.primary);
          set();
        }
      }
    }
  }
}

@riverpod
class PickerColor extends _$PickerColor {
  @override
  int build() => FastDB.getPositiveLong("appColor") ?? 0xffD4AF37;

  void set(Color color) {
    state = color.value;
  }
}

@riverpod
class Auth extends _$Auth {
  @override
  bool build() => FastDB.getBool("isAuthenticated") ?? false;

  void set(bool newValue) {
    state = newValue;
    FastDB.putBool("isAuthenticated", newValue);
  }
}

@riverpod
Future<String> appVersion(Ref ref) async {
  return (await PackageInfo.fromPlatform()).version;
}

final databaseProvider = Provider<Database>((ref) => throw UnimplementedError());


@riverpod
class FamilyRelationList extends _$FamilyRelationList {
  late Database db;

  @override
  List<FamilyRelation> build() {
    readAllFamilyRelations();
    return [];
  }

  Future<void> readAllFamilyRelations() async {
    db = await DatabaseHelper.instance.database;
    final orderBy = '${FamilyRelationFields.id} ASC';
    final result = await db.query(FamilyRelation.tableName, orderBy: orderBy);
    state = result.map((json) => FamilyRelation.fromJson(json)).toList();
  }
  
  Future<FamilyRelation> readFamilyRelation(int id) async {
    final maps = await db.query(
      FamilyRelation.tableName,
      columns: FamilyRelationFields.values,
      where: '${FamilyRelationFields.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return FamilyRelation.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }
  
   Future<int> add(String name) async {
    final familyRelation = FamilyRelation(name:name);
    final id = await db.insert(FamilyRelation.tableName, familyRelation.toJson());
    if (id > 0) {
      state = [...state, familyRelation];
      return id;
    }
    return -1;
  }

  Future<void> delete(int id) async {
    final rid = await db.delete(
      FamilyRelation.tableName,
      where: '${FamilyRelationFields.id} = ?',
      whereArgs: [id],
    );
    if (rid>0) {
      state = state.where((familyRelation) => familyRelation.id != id).toList();
    }
  }

   Future<void> bulkDelete(List<int> ids) async {
    final batch = db.batch();
    for(int id in ids){
      batch.delete(
      FamilyRelation.tableName,
      where: '${FamilyRelationFields.id} = ?',
      whereArgs: [id],
      );
    }
    final results = await batch.commit();
    state = state.where((familyRelation) => !results.contains(familyRelation.id)).toList();
  }

   Future<void> update(FamilyRelation familyRelation) async {
    final id = await  db.update(
      FamilyRelation.tableName,
      familyRelation.toJson(),
      where: '${FamilyRelationFields.id} = ?',
      whereArgs: [familyRelation.id],
    );
    if (id > 0) {
      state = [
        for (final s in state)
          if (s.id == familyRelation.id) familyRelation else s
      ];
    }
  }
}

@riverpod
class MortgageMaterialList extends _$MortgageMaterialList {
  late Database db;

  @override
  List<MortgageMaterial> build() {
    readAllMortgageMaterials();
    return [];
  }

  Future<void> readAllMortgageMaterials() async {
    db = await DatabaseHelper.instance.database;
    final orderBy = '${MortgageMaterialFields.id} ASC';
    final result = await db.query(MortgageMaterial.tableName, orderBy: orderBy);
    state = result.map((json) => MortgageMaterial.fromJson(json)).toList();
  }

   Future<MortgageMaterial> readMortgageMaterial(int id) async {
    final maps = await db.query(
      MortgageMaterial.tableName,
      columns: MortgageMaterialFields.values,
      where: '${MortgageMaterialFields.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return MortgageMaterial.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  Future<int> add(String name) async{
    final mortgageMaterial = MortgageMaterial(name:name);
     final id = await db.insert(MortgageMaterial.tableName, mortgageMaterial.toJson());
    if (id > 0) {
      state = [...state, mortgageMaterial];
      return id;
    }
    return -1;
  }

 Future<void> delete(int id)async {
     final rid = await db.delete(
      MortgageMaterial.tableName,
      where: '${MortgageMaterialFields.id} = ?',
      whereArgs: [id],
    );
    if (rid>0) {
      state = state.where((mortgageMaterial) => mortgageMaterial.id != id).toList();
    } 
  }

   Future<void> bulkDelete(List<int> ids) async {
    final batch = db.batch();
    for(int id in ids){
      batch.delete(
      MortgageMaterial.tableName,
      where: '${MortgageMaterialFields.id} = ?',
      whereArgs: [id],
      );
    }
    final results = await batch.commit();
    state = state.where((item) => !results.contains(item.id)).toList();
  }

   Future<void> update(MortgageMaterial mortgageMaterial) async {
    final id = await  db.update(
      MortgageMaterial.tableName,
      mortgageMaterial.toJson(),
      where: '${ItemFields.id} = ?',
      whereArgs: [mortgageMaterial.id],
    );
    if (id > 0) {
      state = [
        for (final s in state)
          if (s.id == mortgageMaterial.id) mortgageMaterial else s
      ];
    }
  }

}

@riverpod
class ItemList extends _$ItemList {
  late Database db;

  @override
  List<Item> build() {
    readAllItems();
    return [];
  }

  Future<void> readAllItems() async {
    db = await DatabaseHelper.instance.database;
    final orderBy = '${ItemFields.id} ASC';
    final result = await db.query(Item.tableName, orderBy: orderBy);
    state = result.map((json) => Item.fromJson(json)).toList();
  }

  Future<Item> readItem(int id) async {
    final maps = await db.query(
      Item.tableName,
      columns: ItemFields.values,
      where: '${ItemFields.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Item.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  Future<int> add(String name) async {
    final item = Item(name:name);
    final id = await db.insert(Item.tableName, item.toJson());
    if (id > 0) {
      state = [...state, item];
      return id;
    }
    return -1;
  }

 Future<void> bulkDelete(List<int> ids) async {
    final batch = db.batch();
    for(int id in ids){
      batch.delete(
      Item.tableName,
      where: '${ItemFields.id} = ?',
      whereArgs: [id],
      );
    }
    final results = await batch.commit();
    state = state.where((item) => !results.contains(item.id)).toList();
  }

   Future<void> update(Item item) async {
    final id = await  db.update(
      Item.tableName,
      item.toJson(),
      where: '${ItemFields.id} = ?',
      whereArgs: [item.id],
    );
    if (id > 0) {
      state = [
        for (final s in state)
          if (s.id == item.id) item else s
      ];
    }
  }

   Future<void> delete(int id) async {
    final rid = await db.delete(
      Item.tableName,
      where: '${ItemFields.id} = ?',
      whereArgs: [id],
    );
    if (rid>0) {
      state = state.where((item) => item.id != id).toList();
    }
  }

}

@riverpod
class MortgageList extends _$MortgageList {
  late Database db;

  @override
  List<Mortgage> build() {
    readAllMortgages();
    return [];
  }

  Future<void> readAllMortgages() async {
    db = await DatabaseHelper.instance.database;
    final orderBy = '${MortgageFields.id} ASC';
    final result = await db.query(Mortgage.tableName, orderBy: orderBy);
    state = result.map((json) => Mortgage.fromJson(json)).toList();
  }

  Future<int> add(
      String depositorName,
      String relativeName,
      String address,
      double loanAmount,
      double interestRate,
      double weight,
      String additionalDetails,
      int itemId,
      int familyRelationId,
      int mortgageMaterialId,
      ) async {
    final mortgage = Mortgage(
        depositorName: depositorName,
        relativeName: relativeName,
        address: address,
        loanAmount: loanAmount,
        weight: weight,
        additionalDetails: additionalDetails,
        interestRate: interestRate,
        itemId: itemId,
        familyRelationId: familyRelationId,
        mortgageMaterialId: mortgageMaterialId,
        );
    final id = await db.insert(Mortgage.tableName, mortgage.toJson());
    if (id > 0) {
      state = [...state, mortgage];
      return id;
    }
    return -1;
  }

   Future<void> update(Mortgage mortgage) async {
    final id = await  db.update(
      Mortgage.tableName,
      mortgage.toJson(),
      where: '${MortgageFields.id} = ?',
      whereArgs: [mortgage.id],
    );
    if (id > 0) {
      state = [
        for (final s in state)
          if (s.id == mortgage.id) mortgage else s
      ];
    }
  }

  Future<void> delete(int id) async {
    final rid = await db.delete(
      Mortgage.tableName,
      where: '${MortgageFields.id} = ?',
      whereArgs: [id],
    );
    if (rid>0) {
      state = state.where((mortgage) => mortgage.id != id).toList();
    }
  }

  Future<void> bulkDelete(List<int> ids) async {
    final batch = db.batch();
    for(int id in ids){
      batch.delete(
      Mortgage.tableName,
      where: '${MortgageFields.id} = ?',
      whereArgs: [id],
      );
    }
    final results = await batch.commit();
    state = state.where((mortgage) => !results.contains(mortgage.id)).toList();
  }
}
