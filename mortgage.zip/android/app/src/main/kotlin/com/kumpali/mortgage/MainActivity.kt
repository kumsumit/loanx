package com.kumpali.mortgage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
