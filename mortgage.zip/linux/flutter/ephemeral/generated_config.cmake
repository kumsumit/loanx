# Generated code do not commit.
file(TO_CMAKE_PATH "/home/sumit/softwares/flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "/home/sumit/AndroidStudioProjects/mortgage" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 0 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=/home/sumit/softwares/flutter"
  "PROJECT_DIR=/home/sumit/AndroidStudioProjects/mortgage"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=/home/sumit/AndroidStudioProjects/mortgage/.dart_tool/package_config.json"
  "FLUTTER_TARGET=/home/sumit/AndroidStudioProjects/mortgage/lib/main.dart"
)
